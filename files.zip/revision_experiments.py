"""
revision_experiments.py -- the NEW runs the reviewers asked for. Uses the existing
pose_adaptive package unchanged. Run from the pose_adaptive_control folder:

    PYTHONPATH=. python3 revision_experiments.py confirm  --n 200   # R1.8, R3.7  fresh-seed check of sweep picks
    PYTHONPATH=. python3 revision_experiments.py sway     --n 100   # R2.5        sway amplitude/frequency sensitivity
    PYTHONPATH=. python3 revision_experiments.py fixedgain --n 100  # R2.1        fixed-gain grid baseline
    PYTHONPATH=. python3 revision_experiments.py thresholds         # R3.5        alpha / c_th / consistency_th sensitivity

Results go to results/revision_<mode>.csv.  Seeds for confirm/sway/fixedgain start at
SEED_FRESH = 20270000, which does not overlap the study/sweep seeds (20260820 .. 20261019).
Cycle time here charges misses the full time budget (same convention as sweep.py).
"""
import argparse, itertools
from pathlib import Path
import numpy as np, pandas as pd
from pose_adaptive.config import SimConfig
from pose_adaptive.sweep import evaluate

SEED_FRESH = 20270000
OUT = Path("results"); OUT.mkdir(exist_ok=True)
base = SimConfig()
seeds = lambda n: [SEED_FRESH + i for i in range(n)]

def arms():
    c = base.with_control
    return {
        "fixed_Kmax":               c(adaptive=False, use_trigger=False),
        "adaptive_g2.0 (no trig)":  c(adaptive=True, use_trigger=False, gamma=2.0),
        # Table 1 trigger arm (defaults c_th=0.55, T_d=0.15)
        "adaptive_g2.0+trig (Table 1: c_th .55, Td .15)": c(adaptive=True, use_trigger=True, gamma=2.0),
        # sweep picks
        "sweep best throughput (g2, c_th .30, Td .35)": c(adaptive=True, use_trigger=True, gamma=2.0, c_th=0.30, dwell=0.35),
        "sweep most accurate (g1, c_th .30, Td .10)":   c(adaptive=True, use_trigger=True, gamma=1.0, c_th=0.30, dwell=0.10),
    }

def confirm(n):
    rows = [dict(arm=k, **evaluate(v, seeds(n))) for k, v in arms().items()]
    return pd.DataFrame(rows)

def sway(n):
    d0 = base.disturbance; rows = []
    sel = {k: arms()[k] for k in ("fixed_Kmax", "adaptive_g2.0 (no trig)",
                                  "adaptive_g2.0+trig (Table 1: c_th .55, Td .15)")}
    for ka, kf in itertools.product((0.5, 1.0, 2.0), (0.5, 1.0, 2.0)):
        dist = dict(sway_amp_pos=d0.sway_amp_pos * ka, sway_amp_rot=d0.sway_amp_rot * ka,
                    sway_freq=(d0.sway_freq[0] * kf, d0.sway_freq[1] * kf))
        for name, cfg in sel.items():
            rows.append(dict(amp_scale=ka, freq_scale=kf, arm=name,
                             **evaluate(cfg.with_disturbance(**dist), seeds(n))))
    return pd.DataFrame(rows)

def fixedgain(n):
    rows = []
    for k in (1, 2, 3, 4, 5, 6, 7, 8):
        cfg = base.with_control(adaptive=False, use_trigger=False, k_max=float(k), k_min=float(k))
        rows.append(dict(K=k, **evaluate(cfg, seeds(n))))
    return pd.DataFrame(rows)

def thresholds():
    """Open-loop replay on the synthetic test split (as trigger_study.py)."""
    from pose_adaptive import dataset as ds
    df = ds.load(Path("data/synthetic_v1"), "test"); tol = base.task.tol_pos; rows = []
    for alpha, c_th, cons_th, split in itertools.product((0.3, 0.5, 0.7), (0.45, 0.55, 0.70, 0.78),
                                                         (0.45, 0.55, 0.70), (False, True)):
        if not split and cons_th != 0.55: continue            # cons_th only matters for the split trigger
        cfg = (base.with_stream(alpha=alpha)
                   .with_control(use_split_trigger=split, c_th=c_th, consistency_th=cons_th))
        stats = {}
        for sid, seq in df.groupby("sequence_id", sort=False):
            tier = str(sid).split("_")[0]
            tr = ds.replay(seq.reset_index(drop=True), cfg)
            unsafe = ((seq.err_pos.to_numpy() > tol) | (seq.plan_dev.to_numpy() > tol)); f = tr.trigger.to_numpy()
            s = stats.setdefault(tier, [0, 0, 0, 0]); s[0] += f.sum(); s[1] += (f & unsafe).sum(); s[2] += len(f)
        r = dict(alpha=alpha, c_th=c_th, split=split, consistency_th=cons_th if split else np.nan,
                 reachable=(c_th > alpha))
        for tier, (fired, tp, N, _) in stats.items():
            r[f"{tier}_fire"] = fired / N; r[f"{tier}_prec"] = (tp / fired) if fired else np.nan
        rows.append(r)
    return pd.DataFrame(rows)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("mode", choices=["confirm", "sway", "fixedgain", "thresholds"])
    ap.add_argument("--n", type=int, default=100); a = ap.parse_args()
    out = {"confirm": lambda: confirm(a.n), "sway": lambda: sway(a.n),
           "fixedgain": lambda: fixedgain(a.n), "thresholds": thresholds}[a.mode]()
    out.to_csv(OUT / f"revision_{a.mode}.csv", index=False)
    pd.set_option("display.width", 220); pd.set_option("display.float_format", lambda v: f"{v:.3f}")
    print(out.to_string(index=False))
