"""
revision_stats.py -- effect sizes, confidence intervals and throughput tables
for the Paper 648 revision. Reads results/trials.csv and results/sweep.csv;
NO simulation is re-run.

Usage (from the pose_adaptive_control folder):
    python3 revision_stats.py            # writes results/revision_*.csv, prints tables
"""
from pathlib import Path
import numpy as np, pandas as pd
from scipy import stats

R = Path("results"); B_TIME = 7.0           # TaskConfig.time_budget
rng = np.random.default_rng(0); NB = 10000

df = pd.read_csv(R / "trials.csv")
df["success"] = df.committed & ~df.false_approach
df["cyc_incl"] = np.where(df.committed, df.commit_time, B_TIME)   # misses charged the full budget
wide = lambda col: df.pivot(index="seed", columns="arm", values=col)

def boot(x, f, n=NB):
    idx = rng.integers(0, len(x), (n, len(x)))
    return np.percentile(f(x[idx]), [2.5, 97.5])

def cont(a, b, col, scale=1.0):
    W = wide(col) * scale; d = (W[a] - W[b]).to_numpy()
    nz = d[d != 0]; r = stats.rankdata(np.abs(nz))
    rbc = (r[nz > 0].sum() - r[nz < 0].sum()) / r.sum()
    lo, hi = boot(d, lambda m: np.median(m, 1))
    p = stats.wilcoxon(W[a], W[b], zero_method="zsplit").pvalue
    return dict(treatment=a, control=b, metric=col, n=len(d), median_diff=np.median(d),
                ci_lo=lo, ci_hi=hi, rank_biserial=rbc, p=p)

def binary(a, b, col):
    W = wide(col).astype(int); x, y = W[a].to_numpy(), W[b].to_numpy()
    n10, n01 = int(((x == 1) & (y == 0)).sum()), int(((x == 0) & (y == 1)).sum())
    p = stats.binomtest(n10, n10 + n01, .5).pvalue if n10 + n01 else np.nan
    d = (x - y).astype(float); lo, hi = boot(d, lambda m: m.mean(1))
    return dict(treatment=a, control=b, metric=col, n=len(x), rate_treat=x.mean(), rate_ctrl=y.mean(),
                risk_diff=d.mean(), ci_lo=lo, ci_hi=hi, only_treat=n10, only_ctrl=n01,
                odds_ratio=(n10 / n01 if n01 else np.inf), p=p)

# ---- paired comparisons used in the paper -------------------------------
cont_rows = [cont(a, "fixed_Kmax", "track_var", 1e6) for a in ("adaptive_g0.5", "adaptive_g1.0", "adaptive_g2.0")]
cont_rows += [cont("adaptive_g2.0", "fixed_Kmax", "commit_pos_err", 1e3),
              cont("adaptive_g2.0", "fixed_Kmin", "commit_pos_err", 1e3)]
bin_rows = []
for a, b in (("fixed_Kmax+trig", "fixed_Kmax"), ("adaptive_g1.0+trig", "adaptive_g1.0"),
             ("adaptive_g2.0+trig", "adaptive_g2.0"), ("adaptive_g2.0+trig", "adaptive_g2.0+trig_nomc")):
    for col in ("false_approach", "missed"):
        bin_rows.append(binary(a, b, col))
# adaptive vs fixed WITHOUT trigger, success rate (not reported in the manuscript)
bin_rows += [binary("adaptive_g2.0", "fixed_Kmax", "success")]
c, b = pd.DataFrame(cont_rows), pd.DataFrame(bin_rows)
c.to_csv(R / "revision_effects_continuous.csv", index=False); b.to_csv(R / "revision_effects_binary.csv", index=False)

# ---- throughput on the 200-trial set, two cycle-time definitions ----------
g = df.groupby("arm", sort=False)
t = pd.DataFrame({"success": g.success.mean(), "false_appr": g.false_approach.mean(), "miss": g.missed.mean(),
                  "cycle_committed_only": g.commit_time.mean(), "cycle_misses_at_budget": g.cyc_incl.mean()})
t["fpm_committed_only"] = 60 * t.success / t.cycle_committed_only
t["fpm_misses_at_budget"] = 60 * t.success / t.cycle_misses_at_budget
ci = {}
for arm, s in df.groupby("arm"):
    s = s.sort_values("seed"); su, cy = s.success.to_numpy(float), s.cyc_incl.to_numpy()
    i = rng.integers(0, len(s), (NB, len(s)))
    v = 60 * su[i].mean(1) / cy[i].mean(1); ci[arm] = np.percentile(v, [2.5, 97.5])
t["fpm_incl_ci_lo"] = pd.Series({k: v[0] for k, v in ci.items()}); t["fpm_incl_ci_hi"] = pd.Series({k: v[1] for k, v in ci.items()})
t.to_csv(R / "revision_throughput_table1.csv")

# ---- break-even: which pair produced 3.7 s? -----------------------------------
sw = pd.read_csv(R / "sweep.csv"); fx = sw[sw.arm == "fixed_Kmax"].iloc[0]; ad = sw[sw.arm == "adaptive+trig"]
def be(r):  # equal throughput of 60*S/(C + p*FA)
    return (r.success_rate * fx.mean_cycle_s - fx.success_rate * r.mean_cycle_s) / \
           (fx.success_rate * r.false_approach_rate - r.success_rate * fx.false_approach_rate)
ties = ad[ad.success_rate == ad.success_rate.max()].copy(); ties["breakeven_s"] = ties.apply(be, axis=1)
best = ad.loc[[ad.fruit_per_min.idxmax()]].copy(); best["breakeven_s"] = best.apply(be, axis=1)
pd.concat([ties.assign(role="tied for highest success"), best.assign(role="best adaptive throughput")]) \
  .to_csv(R / "revision_breakeven.csv", index=False)

pd.set_option("display.width", 220); pd.set_option("display.float_format", lambda v: f"{v:.4g}")
print("== continuous paired effects ==\n", c.to_string(index=False))
print("\n== binary paired effects ==\n", b.to_string(index=False))
print("\n== throughput on 200-trial set ==\n", t.to_string())
print("\n== break-even candidates ==\n", pd.concat([ties, best])[["gamma", "c_th", "dwell", "success_rate", "false_approach_rate",
      "mean_cycle_s", "fruit_per_min", "breakeven_s"]].to_string(index=False))
